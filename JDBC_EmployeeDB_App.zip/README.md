
# Java JDBC – Employee Database App

## Objective
Simple console app to perform CRUD operations on an Employee database using Java and JDBC.

## Tools
- Java
- MySQL
- JDBC
- VS Code

## How to Use
1. Import the provided SQL script to create the database and table.
2. Edit DB credentials in the Java file.
3. Compile and run `EmployeeApp.java`.

## Setup SQL
```

CREATE DATABASE IF NOT EXISTS employeedb;
USE employeedb;

CREATE TABLE IF NOT EXISTS employee (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    department VARCHAR(100)
);

```
